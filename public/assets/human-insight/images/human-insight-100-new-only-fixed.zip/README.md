# Human Insight — 100 new images only

This corrected package contains ONLY the 100 newly added images.

Verification against the current manifest supplied by the user:
- Existing assets: 48
- New assets: 100
- Duplicate IDs: 0
- Duplicate filenames: 0
- Merged total: 148

Usage:
1. Copy the 100 files inside `images/` into `assets/human-insight/images/`.
   Windows should NOT ask to replace any file.
2. Either:
   - append entries from `added-assets-100.json` to your current `assets` array, or
   - replace your manifest with `manifest-merged-148.json` if it matches your current source manifest.
